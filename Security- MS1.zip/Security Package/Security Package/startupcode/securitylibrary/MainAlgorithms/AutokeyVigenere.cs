﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class AutokeyVigenere : ICryptographicTechnique<string, string>
    {
        private int PT = 0, CT = 0, K = 0, sum = 0;
        private char letter = 'a';
        public string Analyse(string plainText, string cipherText)
        {
            //throw new NotImplementedException();

            string key = "";
            string keyStream = "";
            //string start;
            //string repeatedKey;
            int len = -1;
            //bool flag = false;
            cipherText = cipherText.ToLower();

            for (int i = 0; i < plainText.Length; i++)
            {
                PT = plainText[i] - 'a';
                CT = cipherText[i] - 'a';
                sum = (CT - PT) % 26;
                if (sum < 0)
                    sum += 26 + 'a';
                else sum += 'a';
                letter = (char)sum;
                keyStream += letter;
            }

            for (int i = 0; i < plainText.Length; i++)
            {
                int indx = keyStream.IndexOf(plainText.Substring(0, i));
                if (indx > len)
                {
                    len = indx;
                }
            }

            key += keyStream.Substring(0, len);

            return key;
        }

        public string Decrypt(string cipherText, string key)
        {
            //throw new NotImplementedException();

            string plain = "";
            int count = cipherText.Length - key.Length;
            string newCipher = cipherText.ToLower();

            for (int i = 0; i < count; i += 1)
            {
                CT = newCipher[i] - 'a';
                K = key[i] - 'a';
                sum = (CT - K) % 26;
                if (sum < 0)
                    sum += 26 + 'a';
                else
                    sum += 'a';
                letter = (char)sum;
                key += letter;
            }

            for (int i = 0; i < newCipher.Length; i++)
            {
                CT = newCipher[i] - 'a';
                K = key[i] - 'a';
                sum = (CT - K) % 26;
                if (sum < 0)
                    sum += 26 + 'a';
                else
                    sum += 'a';
                letter = (char)sum;
                plain += letter;
            }

            return plain;
        }

        public string Encrypt(string plainText, string key)
        {
            //throw new NotImplementedException();

            string cipher = "";
            int count = plainText.Length - key.Length;

            for (int i = 0; i < count; i += 1)
            {
                key += plainText[i];
            }

            for (int i = 0; i < plainText.Length; i++)
            {
                PT = plainText[i] - 'a';
                K = key[i] - 'a';
                sum = ((PT + K) % 26) + 'a';
                letter = (char)sum;
                cipher += letter;
            }

            return cipher;
        }
    }
}
