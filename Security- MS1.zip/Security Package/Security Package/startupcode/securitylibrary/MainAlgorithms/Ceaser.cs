﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class Ceaser : ICryptographicTechnique<string, int>
    {

        public string Encrypt(string plainText, int key)
        {
            //throw new NotImplementedException();
            string encryptedText = "";
            foreach (char c in plainText)
            {
                char encryptedChar;
                if (char.IsLetter(c))
                {
                    if (char.IsUpper(c))
                    {
                        encryptedChar = (char)(((c - 'A' + key) % 26) + 'A');
                        encryptedText += encryptedChar;
                    }
                    encryptedChar = (char)(((c - 'a' + key) % 26) + 'a');
                    encryptedText += encryptedChar;
                }
                else
                {
                    encryptedText += c;
                }
            }
            return encryptedText;

        }

        public string Decrypt(string cipherText, int key)
        {
            
            //key = key % 26;
            cipherText = cipherText.ToUpper();
            string decryptedText = "";

            foreach (char c in cipherText)
            {
                if (char.IsLetter(c))
                {
                    int charValue = (int)c;
                    charValue -= key;
                    if (charValue < (int)'A')
                    {
                        charValue += 26;
                    }
                    decryptedText += (char)charValue;
                }
                else
                {
                    decryptedText += c;
                }
            }
            return decryptedText;
        }


        public int Analyse(string plainText, string cipherText)
        {
            plainText = plainText.ToUpper();
            cipherText = cipherText.ToUpper();
            int minDifference = int.MaxValue;
            int bestShift = 0;
            for (int shift = 0; shift < 26; shift++)
            {
                int difference = 0;
                string decryptedText = Decrypt(cipherText, shift);
                for (int i = 0; i < decryptedText.Length; i++)
                {
                    if (char.IsLetter(decryptedText[i]))
                    {
                        difference += Math.Abs(decryptedText[i] - plainText[i]);
                    }
                }
                if (difference < minDifference)
                {
                    minDifference = difference;
                    bestShift = shift;
                }
            }
            return bestShift;
        }


    }
}
