﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class RepeatingkeyVigenere : ICryptographicTechnique<string, string>
    {
        private int PT = 0, CT = 0, K = 0, sum = 0;
        private char letter = 'a';
        public string Analyse(string plainText, string cipherText)
        {
            //throw new NotImplementedException();

            string key = "";
            string keyStream = "";
            string start;
            string repeatedKey;
            int len;
            //bool flag = false;
            cipherText = cipherText.ToLower();

            for (int i = 0; i < plainText.Length; i++)
            {
                PT = plainText[i] - 'a';
                CT = cipherText[i] - 'a';
                sum = (CT - PT) % 26;
                if (sum < 0)
                    sum += 26 + 'a';
                else sum += 'a';
                letter = (char)sum;
                keyStream += letter;
            }

            for (int i = 0; i < keyStream.Length; i++)
            {
                start = keyStream.Substring(0, i);

                for (int j = i; j < keyStream.Length; j++)
                {
                    if (j + i > keyStream.Length - 1)
                        break;

                    repeatedKey = keyStream.Substring(i, i);
                    if (start.Equals(repeatedKey) && i != 0)
                    {
                        len = start.Length;
                        key += keyStream.Substring(0, len);
                        return key;
                    }
                }
            }

            return "";
        }

        public string Decrypt(string cipherText, string key)
        {
            //throw new NotImplementedException();

            string plain = "";
            int count = cipherText.Length - key.Length;
            string newCipher = cipherText.ToLower();

            for (int i = 0; i < count; i += 1)
            {
                key += key[i];
            }

            for (int i = 0; i < newCipher.Length; i++)
            {
                CT = newCipher[i] - 'a';
                K = key[i] - 'a';
                sum = (CT - K) % 26;
                if (sum < 0)
                    sum += 26 + 'a';
                else
                    sum += 'a';
                letter = (char)sum;
                plain += letter;
            }

            return plain;
        }

        public string Encrypt(string plainText, string key)
        {
            //throw new NotImplementedException();

            string cipher = "";
            int count = plainText.Length - key.Length;

            for (int i = 0; i < count; i += 1)
            {
                key += key[i];
            }

            for (int i = 0; i < plainText.Length; i++)
            {
                PT = plainText[i] - 'a';
                K = key[i] - 'a';
                sum = ((PT + K) % 26) + 'a';
                letter = (char)sum;
                cipher += letter;
            }

            return cipher;
        }
    }
}