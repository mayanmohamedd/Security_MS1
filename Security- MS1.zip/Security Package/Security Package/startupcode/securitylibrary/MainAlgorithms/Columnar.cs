﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class Columnar : ICryptographicTechnique<string, List<int>>
    {
        public static List<List<int>> GeneratePermutations(int n)
        {
            List<int> nums = Enumerable.Range(1, n).ToList();
            List<List<int>> permutations = new List<List<int>>();
            Permute(nums, 0, n - 1, permutations);
            return permutations;
        }
        public static void Permute(List<int> nums, int left, int right, List<List<int>> permutations)
        {
            if (left == right)
            {
                permutations.Add(new List<int>(nums));
            }
            else
            {
                for (int i = left; i <= right; i++)
                {
                    Swap(nums, left, i);
                    Permute(nums, left + 1, right, permutations);
                    Swap(nums, left, i);
                }
            }
        }

        public static void Swap(List<int> nums, int i, int j)
        {
            int temp = nums[i];
            nums[i] = nums[j];
            nums[j] = temp;
        }
        public List<int> Analyse(string plainText, string cipherText)
        {
            
            List<List<int>> allPermutations = new List<List<int>>();

            List<int> keys = new List<int>();



            for (int i = 1; i < 8; i++)
            {


                allPermutations = GeneratePermutations(i);

                for (int j = 0; j < allPermutations.Count(); j++)
                {
                    string mycip = Encrypt(plainText, allPermutations[j]);


                    if (cipherText.Equals(mycip, StringComparison.InvariantCultureIgnoreCase))
                    {


                        return allPermutations[j];

                    }
                }

            }



            List<int> zerosList = new List<int>();


            for (int i = 0; i < plainText.Length; i++)
            {
                zerosList.Add(0);
            }


            return zerosList;
        }
      
        public string Decrypt(string cipherText, List<int> key)
        {

            //throw new NotImplementedException();
            cipherText = cipherText.ToUpper();
            int numRows = (int)Math.Ceiling((double)cipherText.Length / key.Count);
            char[,] Table = new char[numRows, key.Count];
            int counter = 0;
            for (int i = 0; i < key.Count; i++)
            {
                int col = key.IndexOf(i + 1);
                for (int j = 0; j < numRows; j++)
                {
                    if (counter >= cipherText.Length)
                    {
                        Table[j, col] = 'X';
                    }
                    else
                    {
                        Table[j, col] = cipherText[counter];
                    }

                    counter++;
                }
            }
            string plainText = "";
            for (int i = 0; i < numRows; i++)
            {
                for (int j = 0; j < key.Count; j++)
                {
                    plainText += Table[i, j];
                }
            }

            return plainText;
        }


        public string Encrypt(string plainText, List<int> key)
        {
            plainText = plainText.ToUpper();
            int numRows = (int)Math.Ceiling((double)plainText.Length / key.Count);
            plainText = plainText.PadRight(numRows * key.Count, 'X');
            char[,] Table = new char[numRows, key.Count];
            int counter = 0;
            for (int i = 0; i < numRows; i++)
            {
                for (int j = 0; j < key.Count; j++)
                {
                    Table[i, j] = plainText[counter];
                    counter++;
                    
                }
            }

            string cipherText = "";
            for (int c = 0; c < key.Count; c++)
            {
                for (int i = 0; i < numRows; i++)
                {
                    cipherText += (char)Table[i, key.IndexOf(c + 1)];
                }
            }
            return cipherText;
        }

    }
}
