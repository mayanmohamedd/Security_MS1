﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class Monoalphabetic : ICryptographicTechnique<string, string>
    {

        public string Analyse(string plainText, string cipherText)
        {
            string plaintext = plainText.ToLower();
            string ciphertext = cipherText.ToLower();
            string alphabet = "abcdefghijklmnopqrstuvwxyz";

            char[] monokey = new char[26];

            bool[] letterUsed = new bool[26];

            // map letters
            for (int i = 0; i < 26; i++)
            {
                int j = 0;
                while (j < ciphertext.Length)

                {
                    if (plaintext.Contains(alphabet[i]) == false)
                    {
                        monokey[i] = ' ';
                        break;
                    }
                    if (plaintext[j] == alphabet[i])
                    {
                        monokey[i] = ciphertext[j];
                        letterUsed[ciphertext[j] - 'a'] = true; // Mark the letter as used
                        break;
                    }
                    j++;
                }
            }

            // Fill in the missing letters in the key
            int index = 0;
            foreach (char letter in alphabet)
            {
                if (!letterUsed[letter - 'a'])
                {
                    while (letterUsed[index])
                    {
                        index++;
                    }
                    monokey[Array.IndexOf(monokey, ' ')] = (char)('a' + index);
                    letterUsed[index] = true;
                }
            }

            return new string(monokey);

        }

        public string Decrypt(string cipherText, string key)
        {

            string alphabet = "abcdefghijklmnopqrstuvwxyz";
            string PlainText = "";

            string ciphertext = cipherText.ToLower();

            foreach (char c in ciphertext)
            {
                for (int i = 0; i < 26; i++)
                {
                    if (c == key[i])
                    {
                        PlainText += alphabet[i];
                        break;
                    }
                }
            }
            return PlainText;
        }

        public string Encrypt(string plainText, string key)
        {
            string alphabet = "abcdefghijklmnopqrstuvwxyz";
            string CipherText = "";

            string plaintext = plainText.ToLower();

            foreach (char c in plaintext)
            {
                for (int i = 0; i < 26; i++)
                {
                    if (c == alphabet[i])
                    {
                        CipherText += key[i];

                    }
                }

            }
            return CipherText;
        }



        /// <summary>
        /// Frequency Information:
        /// E   12.51%
        /// T	9.25
        /// A	8.04
        /// O	7.60
        /// I	7.26
        /// 
        /// N	7.09
        /// S	6.54
        /// R	6.12
        /// H	5.49
        /// L	4.14
        /// D	3.99
        /// C	3.06
        /// U	2.71
        /// M	2.53
        /// F	2.30
        /// P	2.00
        /// G	1.96
        /// W	1.92
        /// Y	1.73
        /// B	1.54
        /// V	0.99
        /// K	0.67
        /// X	0.19
        /// J	0.16
        /// Q	0.11
        /// Z	0.09
        /// </summary>
        /// <param name="cipher"></param>
        /// <returns>Plain text</returns>
        // Increment count for the letter




        public string AnalyseUsingCharFrequency(string cipher)
        {
            string Cipher = cipher.ToLower();
            string englishfrequencies = "etaoinsrhldcumfpgwybvkxjqz";

            List<KeyValuePair<char, int>> dict1 = new List<KeyValuePair<char, int>>();

            //Ascii code of a is 97 and ascii code of z is 122
            for (int i = 97; i <= 122; i++)
            {
                int counter = 0;

                foreach (char ch in Cipher)
                {
                    if (ch == (char)i)
                    {
                        counter++;
                    }
                }

                dict1.Add(new KeyValuePair<char, int>((char)i, counter));
            }

            dict1 = dict1.OrderByDescending(pair => pair.Value).ToList();
            List<char> frequency = new List<char>();

            List<char> chars = new List<char>();

            foreach (KeyValuePair<char, int> pair in dict1)
            {
                chars.Add(pair.Key);
                frequency.Add(englishfrequencies[chars.Count - 1]);
            }

            char[] monokey = new char[Cipher.Length];
            int j = 0;
            foreach (char c in Cipher)
            {
                int index = chars.IndexOf(c);
                if (index != -1)
                {
                    monokey[j] = frequency[index];
                }
                j++;
            }
            string key = new string(monokey);
            return key;
        }
    }
}
