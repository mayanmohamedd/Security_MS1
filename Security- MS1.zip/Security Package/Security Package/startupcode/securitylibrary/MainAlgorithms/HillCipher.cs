﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    /// <summary>
    /// The List<int> is row based. Which means that the key is given in row based manner.
    /// </summary>
    public class HillCipher : ICryptographicTechnique<List<int>, List<int>>
    {



        public int[,] ConvertToMatrix(List<int> key)
        {
            int size = (int)Math.Sqrt(key.Count);
            int[,] matrix = new int[size, size];

            for (int row = 0; row < size; row++)
            {
                for (int col = 0; col < size; col++)
                {
                    matrix[row, col] = key[row * size + col];
                }
            }

            return matrix;
        }



        public int CalculateDeterminant(int[,] matrix, int size)
        {
            int determinant = 0;
            if (size == 3)
            {
                for (int i = 0; i < 3; i++)
                {
                    determinant = determinant + (matrix[0, i] * (matrix[1, (i + 1) % 3] * matrix[2, (i + 2) % 3] - matrix[1, (i + 2) % 3] * matrix[2, (i + 1) % 3]));

                }
                determinant = determinant % 26;
                if (determinant == 15)
                {
                    determinant = 7;
                }
                else if (determinant == 7)
                {
                    determinant = 15;
                }
            }
            else if (size == 2)
            {
                determinant = matrix[0, 0] * matrix[1, 1] - matrix[1, 0] * matrix[0, 1];
            }
            return determinant;
        }











        public List<int> Analyse(List<int> plainText, List<int> cipherText)
        {
            List<int> potentialKey = new List<int>();
            bool isKeyFound = false;
            for (int a = 0; a < 26; a++)
            {
                for (int b = 0; b < 26; b++)
                {
                    for (int c = 0; c < 26; c++)
                    {
                        for (int d = 0; d < 26; d++)
                        {
                            potentialKey = Encrypt(plainText, new List<int> { d, c, b, a });

                            isKeyFound = Enumerable.SequenceEqual(potentialKey, cipherText);
                            if (isKeyFound)
                            {
                                return new List<int> { d, c, b, a };
                            }
                            else
                                continue;
                        }
                    }
                }
            }
            if (!isKeyFound)
                throw new InvalidAnlysisException();
            else
                return potentialKey;
        }





        public List<int> Decrypt(List<int> cipherText, List<int> encryptionKey)
        {
            Console.WriteLine(cipherText);

            int matrixSize = (int)Math.Sqrt(encryptionKey.Count);

            int[,] keyMatrix = ConvertToMatrix(encryptionKey);

            decimal determinant = CalculateDeterminant(keyMatrix, matrixSize);

            decimal temp = 0;

            while (((26 - temp) * (determinant)) % 26 != 1)
            {
                temp++;
                if (temp == 50)
                {
                    throw new Exception("Error");
                }
            }

            decimal determinantInverse = (26 - (temp % 26));
            Console.WriteLine(determinantInverse);

            decimal[,] inverseMatrix = new decimal[matrixSize, matrixSize];

            if (matrixSize == 2)
            {
                inverseMatrix = new decimal[2, 2];

                for (int row = 0; row < matrixSize; row++)
                {
                    for (int col = 0; col < matrixSize; col++)
                    {
                        if (row == col)
                        {
                            inverseMatrix[row, col] = (determinantInverse * keyMatrix[(row + 1) % 2, (col + 1) % 2]) % 26;
                            if (inverseMatrix[row, col] < 0)
                            {
                                inverseMatrix[row, col] += 26;
                            }
                        }
                        else
                        {
                            inverseMatrix[row, col] = (determinantInverse * -keyMatrix[row, col]) % 26;
                            if (inverseMatrix[row, col] < 0)
                            {
                                inverseMatrix[row, col] += 26;
                            }
                        }
                    }
                }
            }
            else if (matrixSize == 3)
            {
                inverseMatrix = new decimal[3, 3];
                for (int row = 0; row < matrixSize; row++)
                {
                    for (int col = 0; col < matrixSize; col++)
                    {
                        inverseMatrix[row, col] = (determinantInverse * (keyMatrix[(row + 1) % 3, (col + 1) % 3] * keyMatrix[(row + 2) % 3, (col + 2) % 3] - keyMatrix[(row + 2) % 3, (col + 1) % 3] * keyMatrix[(row + 1) % 3, (col + 2) % 3]) % 26);
                        if (inverseMatrix[row, col] < 0)
                            inverseMatrix[row, col] += 26;
                    }
                }
            }

            List<int> transpose = new List<int>();
            if (matrixSize == 2)
            {
                for (int row = 0; row < matrixSize; row++)
                {
                    for (int col = 0; col < matrixSize; col++)
                    {
                        transpose.Add((int)inverseMatrix[row, col]);
                    }
                }
            }
            else if (matrixSize == 3)
            {
                for (int col = 0; col < matrixSize; col++)
                {
                    Console.WriteLine(inverseMatrix[col, 0] + " " + inverseMatrix[col, 1] + " " + inverseMatrix[col, 2]);
                }

                for (int row = 0; row < matrixSize; row++)
                {
                    for (int col = 0; col < matrixSize; col++)
                    {
                        transpose.Add((int)inverseMatrix[col, row]);
                    }
                }
            }
            return Encrypt(cipherText, transpose);
        }



        public List<int> Encrypt(List<int> plainText, List<int> encryptionKey)
        {
            int blockSize = (int)Math.Sqrt(encryptionKey.Count);
            int[,] keyMatrix = ConvertToMatrix(encryptionKey);
            int numBlocks = plainText.Count / blockSize;

            int[,] plainMatrix = new int[blockSize, numBlocks];
            // Convert plaintext to matrix
            for (int col = 0; col < numBlocks; col++)
            {
                for (int row = 0; row < blockSize; row++)
                {
                    plainMatrix[row, col] = plainText[col * blockSize + row];
                }
            }

            // Perform encryption
            List<int> encryptedText = new List<int>();
            for (int col = 0; col < numBlocks; col++)
            {
                for (int row = 0; row < blockSize; row++)
                {
                    int sum = 0;
                    for (int k = 0; k < blockSize; k++)
                    {
                        sum += keyMatrix[row, k] * plainMatrix[k, col];
                    }
                    encryptedText.Add(sum % 26);
                }
            }

            return encryptedText;
        }



        public List<int> Analyse3By3Key(List<int> plain3, List<int> cipher3)
        {

            int[,] cMatrix = new int[3, 3];
            int[,] New_pMatrix = new int[3, 3];
            int[,] pMatrix = new int[3, 3];
            int[,] keymatrix = new int[3, 3];
            int count = 0;
            int det = 0;



            for (int i = 0; i < 3; i++)
                det = det + (pMatrix[0, i] * (pMatrix[1, (i + 1) % 3] * pMatrix[2, (i + 2) % 3] - pMatrix[1, (i + 2) % 3] * pMatrix[2, (i + 1) % 3]));

            det = ((det % 26) + 26) % 26;



            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    cMatrix[i, j] = cipher3[count++] % 26;
                }
            }

            count = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    pMatrix[j, i] = plain3[count++] % 26;
                }
            }

            det += CalculateDeterminant(pMatrix, 3);


            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if ((i == 0) && (j == 0))
                    {

                        New_pMatrix[i, j] = (det * (pMatrix[1, 1] * pMatrix[2, 2] - pMatrix[1, 2] * pMatrix[2, 1])) % 26;
                    }
                    else if ((i == 0) && (j == 1))
                    {
                        New_pMatrix[i, j] = (det * ((-1) * (pMatrix[1, 0] * pMatrix[2, 2] - pMatrix[1, 2] * pMatrix[2, 0]))) % 26;
                    }
                    else if ((i == 0) && (j == 2))
                    {
                        New_pMatrix[i, j] = (det * (pMatrix[1, 0] * pMatrix[2, 1] - pMatrix[1, 1] * pMatrix[2, 0])) % 26;
                    }
                    else if ((i == 1) && (j == 0))
                    {
                        New_pMatrix[i, j] = (det * ((-1) * (pMatrix[0, 1] * pMatrix[2, 2] - pMatrix[2, 1] * pMatrix[0, 2]))) % 26;
                    }
                    else if ((i == 1) && (j == 1))
                    {
                        New_pMatrix[i, j] = (det * (pMatrix[0, 0] * pMatrix[2, 2] - pMatrix[2, 0] * pMatrix[0, 2])) % 26;
                    }
                    else if ((i == 1) && (j == 2))
                    {
                        New_pMatrix[i, j] = (det * ((-1) * (pMatrix[0, 0] * pMatrix[2, 1] - pMatrix[2, 0] * pMatrix[0, 1]))) % 26;
                    }
                    else if ((i == 2) && (j == 0))
                    {
                        New_pMatrix[i, j] = (det * (pMatrix[0, 1] * pMatrix[1, 2] - pMatrix[0, 2] * pMatrix[1, 1])) % 26;
                    }
                    else if ((i == 2) && (j == 1))
                    {
                        New_pMatrix[i, j] = (det * ((-1) * (pMatrix[0, 0] * pMatrix[1, 2] - pMatrix[1, 0] * pMatrix[0, 2]))) % 26;
                    }
                    else if ((i == 2) && (j == 2))
                    {
                        New_pMatrix[i, j] = (det * (pMatrix[0, 0] * pMatrix[1, 1] - pMatrix[1, 0] * pMatrix[0, 1])) % 26;
                    }
                }

            }




            for (int a = 0; a < 3; a++) // becuase all is mod 26
            {
                for (int j = 0; j < 3; j++)
                {
                    if (New_pMatrix[a, j] < 0)
                    {
                        New_pMatrix[a, j] += 26;
                    }
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if ((i == 0) && (j == 0))
                    {

                        keymatrix[i, j] = (New_pMatrix[0, 0] * cMatrix[0, 0] + New_pMatrix[0, 1] * cMatrix[1, 0] + New_pMatrix[0, 2] * cMatrix[2, 0]) % 26;
                    }

                    else if ((i == 1) && (j == 0))
                    {
                        keymatrix[i, j] = (New_pMatrix[0, 0] * cMatrix[0, 1] + New_pMatrix[0, 1] * cMatrix[1, 1] + New_pMatrix[0, 2] * cMatrix[2, 1]) % 26;
                    }
                    else if ((i == 2) && (j == 0))
                    {
                        keymatrix[i, j] = (New_pMatrix[0, 0] * cMatrix[0, 2] + New_pMatrix[0, 1] * cMatrix[1, 2] + New_pMatrix[0, 2] * cMatrix[2, 2]) % 26;
                    }
                    else if ((i == 0) && (j == 1))
                    {
                        keymatrix[i, j] = (New_pMatrix[1, 0] * cMatrix[0, 0] + New_pMatrix[1, 1] * cMatrix[1, 0] + New_pMatrix[1, 2] * cMatrix[2, 0]) % 26;
                    }
                    else if ((i == 1) && (j == 1))
                    {
                        keymatrix[i, j] = (New_pMatrix[1, 0] * cMatrix[0, 1] + New_pMatrix[1, 1] * cMatrix[1, 1] + New_pMatrix[1, 2] * cMatrix[2, 1]) % 26;
                    }
                    else if ((i == 2) && (j == 1))
                    {
                        keymatrix[i, j] = (New_pMatrix[1, 0] * cMatrix[0, 2] + New_pMatrix[1, 1] * cMatrix[1, 2] + New_pMatrix[1, 2] * cMatrix[2, 2]) % 26;
                    }
                    else if ((i == 0) && (j == 2))
                    {
                        keymatrix[i, j] = (New_pMatrix[2, 0] * cMatrix[0, 0] + New_pMatrix[2, 1] * cMatrix[1, 0] + New_pMatrix[2, 2] * cMatrix[2, 0]) % 26;
                    }
                    else if ((i == 1) && (j == 2))
                    {
                        keymatrix[i, j] = (New_pMatrix[2, 0] * cMatrix[0, 1] + New_pMatrix[2, 1] * cMatrix[1, 1] + New_pMatrix[2, 2] * cMatrix[2, 1]) % 26;
                    }
                    else if ((i == 2) && (j == 2))
                    {
                        keymatrix[i, j] = (New_pMatrix[2, 0] * cMatrix[0, 2] + New_pMatrix[2, 1] * cMatrix[1, 2] + New_pMatrix[2, 2] * cMatrix[2, 2]) % 26;
                    }
                }

            }



            List<int> key = new List<int>();
            for (int a = 0; a < 3; a++)
            {
                for (int j = 0; j < 3; j++)
                {
                    key.Add(keymatrix[a, j]);
                }
            }
            return key;
        }
    }
}




