﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class RailFence : ICryptographicTechnique<string, int>
    {
        public int Analyse(string plainText, string cipherText)
        {
            //throw new NotImplementedException();

            plainText = plainText.ToLower();
            cipherText = cipherText.ToLower();

            int key = 1;
            for (int i = 1; i < plainText.Length; i++)
            {
                for (int j = 1; j < plainText.Length; j++)
                {

                    if (cipherText[i] == plainText[j] && cipherText[i + 1] == plainText[j + key])
                    {
                        return key;
                    }
                    key++;
                }
            }
            return 0;
        }

        public string Decrypt(string cipherText, int key)
        {
            //throw new NotImplementedException();

            String plain = "";
            double len = cipherText.Length;
            int count = (int)Math.Ceiling(len / key);

            for (int i = 0; i < count; i++)
            {
                for (int j = i; j < len; j += count)
                {
                    if (j > len)
                        break;
                    plain += cipherText[j];
                }
            }

            return plain;
        }

        public string Encrypt(string plainText, int key)
        {
            //throw new NotImplementedException();

            String cipher = "";
            int len = plainText.Length;
            for (int i = 0; i < key; i++)
            {
                for (int j = i; j < len; j += key)
                {
                    if (j > len)
                        break;
                    cipher += plainText[j];
                }
            }
            return cipher;
        }
    }
}
